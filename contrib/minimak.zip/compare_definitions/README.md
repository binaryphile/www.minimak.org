These text files are the keyboard definitions that you
can use with the keyboard layout compare tool that you
can find at [patorjk.com site](http://patorjk.com/keyboard-layout-analyzer/).

Use them with the _Import_ button in the _Configuration_ tab.
