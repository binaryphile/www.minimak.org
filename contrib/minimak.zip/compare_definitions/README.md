These text files are the keyboard definitions that you
can use with the keyboard layout compare tool that you
can find at [patorjk.com site](http://patorjk.com/keyboard-layout-analyzer/).

Use them with the _Import_ button in the _Configuration_ tab.

Note: the keyboard layout tool has been updated to allow other layouts,
such as Minimak to be submitted.  All three Minimak layouts are now
available in the dropdown menu for preconfigured layouts.

