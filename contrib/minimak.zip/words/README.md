These are word lists which focus on the letters changed in the Minimak
layouts.

They can be used with the cross-platform [TIPP10] typing tutor.

In TIPP10, click the third tab in the lesson list to see your custom
lessons.  From the dropdown, select _Import_ and open the word list file
which corresponds with your Minimak layout.  Change the name if you
desire, and make sure the lesson type is _Word_.  Change any other
settings you desire, then start the lesson.
